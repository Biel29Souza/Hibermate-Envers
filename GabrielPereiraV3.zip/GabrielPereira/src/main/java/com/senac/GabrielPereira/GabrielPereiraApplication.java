package com.senac.GabrielPereira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GabrielPereiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(GabrielPereiraApplication.class, args);
	}

}
