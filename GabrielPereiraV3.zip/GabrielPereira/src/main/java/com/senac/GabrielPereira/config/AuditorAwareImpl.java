package com.senac.GabrielPereira.config;

public class AuditorAwareImpl {
}
