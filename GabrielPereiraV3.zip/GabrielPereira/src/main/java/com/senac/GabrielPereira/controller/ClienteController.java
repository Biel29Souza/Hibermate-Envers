package com.senac.GabrielPereira.controller;

import com.senac.GabrielPereira.entity.Cliente;
import com.senac.GabrielPereira.repository.ClienteRepository;
import jakarta.persistence.EntityManager;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteRepository clienteRepository;
    private final EntityManager entityManager;

    public ClienteController(ClienteRepository clienteRepository, EntityManager entityManager) {
        this.clienteRepository = clienteRepository;
        this.entityManager = entityManager;
    }

    @PostMapping
    public Cliente criar(@RequestBody Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    @PutMapping("/{id}")
    public Cliente atualizar(@PathVariable Long id, @RequestBody Cliente dados) {
        Cliente existente = clienteRepository.findById(id).orElseThrow();
        existente.setNome(dados.getNome());
        existente.setEmail(dados.getEmail());
        return clienteRepository.save(existente);
    }

    @GetMapping
    public List<Cliente> listar() {
        return clienteRepository.findAll();
    }

    @GetMapping("/{id}/revisao/{rev}")
    public ResponseEntity<Cliente> buscarVersaoRevisada(@PathVariable Long id, @PathVariable int rev) {
        AuditReader reader = AuditReaderFactory.get(entityManager);
        Cliente versao = reader.find(Cliente.class, id, rev);

        if (versao == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(versao);
    }
}
